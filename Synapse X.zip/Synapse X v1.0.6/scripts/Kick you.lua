wait(0)
game.Players.LocalPlayer:Kick(".")