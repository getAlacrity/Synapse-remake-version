task.spawn(function()
    _G.aqua = _G.aqua or {}
    _G.aqua.superfarmer = true
    if _G.aqua.superfarmer then
        game:GetService("CoreGui").PurchasePromptApp.Enabled = false
        task.spawn(function() 
            for i = 1, 300 do
                task.spawn(function() 
                    while _G.aqua.superfarmer and task.wait() do
                        game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("EventEvents"):WaitForChild("SpawnEvilEye"):InvokeServer()
                        game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("EventEvents"):WaitForChild("KillEvilEye"):InvokeServer()
                    end
                end)
            end 
        end)
        task.spawn(function()
            for i = 1, 80 do
                task.spawn(function()
                    while _G.aqua.superfarmer and task.wait() do
                        game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("SpinEvents"):WaitForChild("PurchaseSpin"):InvokeServer()
                        game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("SpinEvents"):WaitForChild("PerformSpin"):InvokeServer()
                    end
                end)
            end
        end)
    end
end)